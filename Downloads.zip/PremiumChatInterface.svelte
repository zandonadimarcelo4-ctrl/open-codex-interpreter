<script lang="ts">
	import { onMount } from 'svelte';
	import { tweened } from 'svelte/motion';
	import { cubicOut, elasticOut } from 'svelte/easing';

	interface Message {
		id: string;
		role: 'user' | 'assistant';
		content: string;
		timestamp: Date;
		agentName?: string;
		isStreaming?: boolean;
	}

	let messages: Message[] = [
		{
			id: '1',
			role: 'assistant',
			content: 'Olá! Sou seu assistente de IA Elite. Como posso ajudá-lo hoje?',
			timestamp: new Date(),
			agentName: 'AutoGen Elite'
		}
	];

	let inputValue = '';
	let isLoading = false;
	let scrollContainer: HTMLDivElement;

	const messageScale = tweened(0.8, {
		duration: 300,
		easing: elasticOut
	});

	const messageOpacity = tweened(0, {
		duration: 200
	});

	onMount(() => {
		messageScale.set(1);
		messageOpacity.set(1);
	});

	const scrollToBottom = () => {
		if (scrollContainer) {
			setTimeout(() => {
				scrollContainer.scrollTop = scrollContainer.scrollHeight;
			}, 0);
		}
	};

	const handleSendMessage = async () => {
		if (!inputValue.trim()) return;

		const userMessage: Message = {
			id: Date.now().toString(),
			role: 'user',
			content: inputValue,
			timestamp: new Date()
		};

		messages = [...messages, userMessage];
		inputValue = '';
		isLoading = true;

		scrollToBottom();

		// Simular resposta
		setTimeout(() => {
			const assistantMessage: Message = {
				id: (Date.now() + 1).toString(),
				role: 'assistant',
				content: `Você pediu: "${userMessage.content}"\n\nEstou processando sua solicitação com minha equipe de agentes especializados...`,
				timestamp: new Date(),
				agentName: 'AutoGen Elite'
			};
			messages = [...messages, assistantMessage];
			isLoading = false;
			scrollToBottom();
		}, 1500);
	};

	const handleKeyPress = (e: KeyboardEvent) => {
		if (e.key === 'Enter' && !e.shiftKey) {
			e.preventDefault();
			handleSendMessage();
		}
	};
</script>

<div class="flex flex-col h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 text-white">
	<!-- Header -->
	<div class="border-b border-purple-500/20 bg-slate-900/50 backdrop-blur-xl px-6 py-4">
		<div class="flex items-center justify-between">
			<div>
				<h1 class="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-400">
					AutoGen Elite Chat
				</h1>
				<p class="text-sm text-gray-400">Powered by Open Interpreter + Autogen</p>
			</div>
			<div class="flex items-center gap-2">
				<div class="w-3 h-3 rounded-full bg-green-400 animate-pulse" />
				<span class="text-sm text-gray-400">Online</span>
			</div>
		</div>
	</div>

	<!-- Messages Container -->
	<div bind:this={scrollContainer} class="flex-1 overflow-y-auto p-6 space-y-4 scrollbar-hide">
		{#each messages as message (message.id)}
			<div
				class="flex {message.role === 'user' ? 'justify-end' : 'justify-start'} animate-fadeIn"
				style="
					opacity: {$messageOpacity};
					transform: scale({$messageScale});
				"
			>
				<div
					class="max-w-xs lg:max-w-md xl:max-w-lg group relative"
					class:user-message={message.role === 'user'}
					class:assistant-message={message.role === 'assistant'}
				>
					{#if message.role === 'assistant' && message.agentName}
						<div class="text-xs font-semibold text-purple-400 mb-1 px-4 pt-3">
							{message.agentName}
						</div>
					{/if}

					<div class="px-4 py-3 rounded-lg backdrop-blur-xl border transition-all duration-300 hover:shadow-lg"
						class:bg-gradient-to-br={message.role === 'user'}
						class:from-purple-600={message.role === 'user'}
						class:to-pink-600={message.role === 'user'}
						class:border-purple-500/50={message.role === 'user'}
						class:bg-slate-800/50={message.role === 'assistant'}
						class:border-purple-500/20={message.role === 'assistant'}
						class:hover:border-purple-500/50={message.role === 'assistant'}
						class:hover:bg-slate-800/80={message.role === 'assistant'}
					>
						<p class="text-sm leading-relaxed">{message.content}</p>
					</div>

					<div class="text-xs text-gray-500 mt-1 px-4 pb-2">
						{message.timestamp.toLocaleTimeString('pt-BR', {
							hour: '2-digit',
							minute: '2-digit'
						})}
					</div>
				</div>
			</div>
		{/each}

		{#if isLoading}
			<div class="flex justify-start">
				<div class="bg-slate-800/50 border border-purple-500/20 rounded-lg px-4 py-3 backdrop-blur-xl">
					<div class="flex space-x-2">
						<div class="w-2 h-2 bg-purple-400 rounded-full animate-bounce" />
						<div class="w-2 h-2 bg-purple-400 rounded-full animate-bounce" style="animation-delay: 0.1s" />
						<div class="w-2 h-2 bg-purple-400 rounded-full animate-bounce" style="animation-delay: 0.2s" />
					</div>
				</div>
			</div>
		{/if}
	</div>

	<!-- Input Area -->
	<div class="border-t border-purple-500/20 bg-slate-900/50 backdrop-blur-xl p-6">
		<div class="flex gap-3">
			<button
				class="p-2 rounded-lg bg-slate-800/50 border border-purple-500/20 hover:bg-slate-800 hover:border-purple-500/50 transition-all duration-300 text-gray-400 hover:text-purple-400"
				title="Adicionar arquivo"
			>
				<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
					<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4" />
				</svg>
			</button>

			<input
				type="text"
				bind:value={inputValue}
				on:keypress={handleKeyPress}
				placeholder="Digite sua mensagem... (Shift+Enter para nova linha)"
				disabled={isLoading}
				class="flex-1 bg-slate-800/50 border border-purple-500/20 rounded-lg px-4 py-2 text-white placeholder-gray-500 focus:outline-none focus:border-purple-500/50 focus:ring-2 focus:ring-purple-500/20 transition-all duration-300 disabled:opacity-50"
			/>

			<button
				on:click={handleSendMessage}
				disabled={!inputValue.trim() || isLoading}
				class="px-4 py-2 rounded-lg bg-gradient-to-r from-purple-600 to-pink-600 text-white font-semibold hover:shadow-lg hover:shadow-purple-500/50 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed hover:scale-105"
			>
				<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
					<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 19l9-9m0 0l-9-9m9 9H3" />
				</svg>
			</button>
		</div>

		<div class="text-xs text-gray-500 mt-2 text-center">
			Powered by AutoGen Framework + Open Interpreter
		</div>
	</div>
</div>

<style>
	:global(.scrollbar-hide::-webkit-scrollbar) {
		display: none;
	}

	:global(.scrollbar-hide) {
		-ms-overflow-style: none;
		scrollbar-width: none;
	}

	@keyframes fadeIn {
		from {
			opacity: 0;
			transform: translateY(10px);
		}
		to {
			opacity: 1;
			transform: translateY(0);
		}
	}

	:global(.animate-fadeIn) {
		animation: fadeIn 0.3s ease-out;
	}

	.user-message {
		@apply bg-gradient-to-br from-purple-600 to-pink-600 border-purple-500/50 text-white rounded-lg rounded-tr-none;
	}

	.assistant-message {
		@apply bg-slate-800/50 border-purple-500/20 text-gray-100 rounded-lg rounded-tl-none;
	}
</style>
