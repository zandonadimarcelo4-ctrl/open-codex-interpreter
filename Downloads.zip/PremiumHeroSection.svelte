<script lang="ts">
	import { onMount } from 'svelte';
	import { tweened } from 'svelte/motion';
	import { cubicOut } from 'svelte/easing';

	let scrollY = 0;
	let mouseX = 0;
	let mouseY = 0;

	// Animações tweened
	const parallaxOffset = tweened(0, {
		duration: 800,
		easing: cubicOut
	});

	const glowIntensity = tweened(0.5, {
		duration: 1000,
		easing: cubicOut
	});

	onMount(() => {
		const handleScroll = () => {
			scrollY = window.scrollY;
			parallaxOffset.set(scrollY * 0.5);
		};

		const handleMouseMove = (e: MouseEvent) => {
			mouseX = e.clientX;
			mouseY = e.clientY;
			glowIntensity.set(0.8);
		};

		window.addEventListener('scroll', handleScroll);
		window.addEventListener('mousemove', handleMouseMove);

		return () => {
			window.removeEventListener('scroll', handleScroll);
			window.removeEventListener('mousemove', handleMouseMove);
		};
	});

	const rotateX = (mouseY - window.innerHeight / 2) * 0.01;
	const rotateY = (mouseX - window.innerWidth / 2) * 0.01;
</script>

<section class="hero-section relative min-h-screen overflow-hidden bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
	<!-- Animated Background -->
	<div class="absolute inset-0 overflow-hidden">
		<!-- Parallax Layers -->
		<div
			class="absolute inset-0 opacity-30"
			style="transform: translateY({$parallaxOffset}px)"
		>
			<div class="absolute top-0 left-1/4 w-96 h-96 bg-purple-500 rounded-full mix-blend-screen filter blur-3xl opacity-20 animate-blob" />
			<div class="absolute top-1/3 right-1/4 w-96 h-96 bg-blue-500 rounded-full mix-blend-screen filter blur-3xl opacity-20 animate-blob animation-delay-2000" />
			<div class="absolute bottom-0 left-1/2 w-96 h-96 bg-pink-500 rounded-full mix-blend-screen filter blur-3xl opacity-20 animate-blob animation-delay-4000" />
		</div>

		<!-- Animated Grid -->
		<div class="absolute inset-0 opacity-10">
			<svg class="w-full h-full" style="transform: translateY({$parallaxOffset * 0.3}px)">
				<defs>
					<pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
						<path d="M 40 0 L 0 0 0 40" fill="none" stroke="white" stroke-width="0.5" />
					</pattern>
				</defs>
				<rect width="100%" height="100%" fill="url(#grid)" />
			</svg>
		</div>

		<!-- Glow Effect -->
		<div
			class="absolute inset-0 pointer-events-none"
			style="
				background: radial-gradient(circle at {mouseX}px {mouseY}px, rgba(168, 85, 247, {$glowIntensity}), transparent 50%);
				opacity: {$glowIntensity};
			"
		/>
	</div>

	<!-- Content -->
	<div class="relative z-10 h-screen flex items-center justify-center px-4">
		<div class="max-w-4xl mx-auto text-center space-y-8">
			<!-- Badge -->
			<div class="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-purple-500/50 bg-purple-500/10 backdrop-blur-sm hover:bg-purple-500/20 transition-all duration-300">
				<span class="w-2 h-2 rounded-full bg-purple-400 animate-pulse" />
				<span class="text-sm font-medium text-purple-300">Powered by AutoGen + Open Interpreter</span>
			</div>

			<!-- Main Title with 3D Effect -->
			<div
				class="space-y-4 perspective"
				style="
					transform: perspective(1000px) rotateX({rotateX}deg) rotateY({rotateY}deg);
					transition: transform 0.1s ease-out;
				"
			>
				<h1 class="text-6xl md:text-7xl lg:text-8xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-400 via-pink-400 to-blue-400 leading-tight">
					AutoGen Elite
				</h1>
				<p class="text-xl md:text-2xl text-gray-300 max-w-2xl mx-auto">
					Plataforma de Agentes IA Colaborativos com Execução de Código Interpretado
				</p>
			</div>

			<!-- Features Grid -->
			<div class="grid grid-cols-1 md:grid-cols-3 gap-4 pt-8">
				{#each [
					{ icon: '🤖', title: 'Multi-Agent', desc: 'Equipe de agentes especializados' },
					{ icon: '⚡', title: 'Open Interpreter', desc: 'Execução de código em tempo real' },
					{ icon: '🔗', title: 'LangChain', desc: 'Integração com modelos avançados' }
				] as feature}
					<div
						class="group relative px-6 py-4 rounded-lg border border-purple-500/20 bg-purple-500/5 hover:bg-purple-500/10 backdrop-blur transition-all duration-300 hover:border-purple-500/50 hover:shadow-lg hover:shadow-purple-500/20"
					>
						<div class="text-2xl mb-2">{feature.icon}</div>
						<h3 class="font-semibold text-white mb-1">{feature.title}</h3>
						<p class="text-sm text-gray-400">{feature.desc}</p>
					</div>
				{/each}
			</div>

			<!-- CTA Buttons -->
			<div class="flex flex-wrap justify-center gap-4 pt-8">
				<button
					class="px-8 py-3 rounded-lg bg-gradient-to-r from-purple-500 to-pink-500 text-white font-semibold hover:shadow-lg hover:shadow-purple-500/50 transition-all duration-300 hover:scale-105"
				>
					Começar Agora
				</button>
				<button
					class="px-8 py-3 rounded-lg border border-purple-500/50 text-purple-300 font-semibold hover:bg-purple-500/10 transition-all duration-300"
				>
					Ver Documentação
				</button>
			</div>
		</div>
	</div>

	<!-- Scroll Indicator -->
	<div class="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-10">
		<div class="animate-bounce">
			<svg class="w-6 h-6 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
				<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 14l-7 7m0 0l-7-7m7 7V3" />
			</svg>
		</div>
	</div>
</section>

<style>
	:global(body) {
		overflow-x: hidden;
	}

	.hero-section {
		position: relative;
	}

	@keyframes blob {
		0%, 100% {
			transform: translate(0, 0) scale(1);
		}
		33% {
			transform: translate(30px, -50px) scale(1.1);
		}
		66% {
			transform: translate(-20px, 20px) scale(0.9);
		}
	}

	:global(.animate-blob) {
		animation: blob 7s infinite;
	}

	:global(.animation-delay-2000) {
		animation-delay: 2s;
	}

	:global(.animation-delay-4000) {
		animation-delay: 4s;
	}

	:global(.perspective) {
		perspective: 1000px;
	}
</style>
