"""
AutoGen Elite Platform - CLI Premium
Interface bonita e interativa para linha de comando
"""

import asyncio
import json
import sys
from typing import Optional, List
from datetime import datetime
from enum import Enum

try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.syntax import Syntax
    from rich.table import Table
    from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn
    from rich.prompt import Prompt, Confirm
    from rich.layout import Layout
    from rich.live import Live
    from rich.align import Align
    from rich.text import Text
    from rich.markdown import Markdown
except ImportError:
    print("Instale rich: pip install rich")
    sys.exit(1)

from architecture import AgentTeam, Task, TaskStatus, AgentConfig, AgentRole, InterpreterAgent, OrchestratorAgent


class CLITheme:
    """Tema de cores para CLI"""
    PRIMARY = "cyan"
    SECONDARY = "magenta"
    SUCCESS = "green"
    ERROR = "red"
    WARNING = "yellow"
    INFO = "blue"


class AutoGenCLI:
    """Interface CLI para AutoGen Elite Platform"""
    
    def __init__(self):
        self.console = Console()
        self.team = AgentTeam()
        self.current_session: Optional[str] = None
        self._setup_team()
    
    def _setup_team(self):
        """Configura equipe padrão"""
        # Criar agentes
        architect = InterpreterAgent(AgentConfig(
            name="Architect",
            role=AgentRole.ARCHITECT,
            system_prompt="Você é um arquiteto de sistemas"
        ))
        
        developer = InterpreterAgent(AgentConfig(
            name="Developer",
            role=AgentRole.DEVELOPER,
            system_prompt="Você é um desenvolvedor especializado"
        ))
        
        designer = InterpreterAgent(AgentConfig(
            name="Designer",
            role=AgentRole.DESIGNER,
            system_prompt="Você é um designer especializado"
        ))
        
        executor = InterpreterAgent(AgentConfig(
            name="Executor",
            role=AgentRole.EXECUTOR,
            system_prompt="Você executa tarefas"
        ))
        
        # Adicionar à equipe
        self.team.add_agent(architect)
        self.team.add_agent(developer)
        self.team.add_agent(designer)
        self.team.add_agent(executor)
        
        # Configurar orquestrador
        orchestrator = OrchestratorAgent(
            AgentConfig(
                name="Orchestrator",
                role=AgentRole.ARCHITECT
            ),
            team={
                "architect": architect,
                "developer": developer,
                "designer": designer,
                "executor": executor
            }
        )
        self.team.set_orchestrator(orchestrator)
    
    def print_header(self):
        """Imprime header da aplicação"""
        header_text = """
╔═══════════════════════════════════════════════════════════════╗
║                  🤖 AutoGen Elite Platform 🤖                 ║
║              Open Interpreter + Autogen Integration           ║
║                    Powered by LangChain                       ║
╚═══════════════════════════════════════════════════════════════╝
        """
        self.console.print(header_text, style=f"bold {CLITheme.PRIMARY}")
    
    def print_welcome(self):
        """Imprime mensagem de boas-vindas"""
        welcome_panel = Panel(
            Markdown("""
# Bem-vindo ao AutoGen Elite Platform

Uma plataforma integrada de agentes IA colaborativos com:
- **Open Interpreter**: Execução de código interpretado
- **Autogen**: Orquestração automática de agentes
- **LangChain**: Integração com modelos de linguagem

### Comandos Disponíveis:
- `task` - Criar e executar nova tarefa
- `status` - Ver status da equipe
- `history` - Ver histórico de tarefas
- `agents` - Listar agentes disponíveis
- `config` - Configurar plataforma
- `help` - Mostrar ajuda
- `exit` - Sair
            """),
            title="[bold cyan]AutoGen Elite[/bold cyan]",
            border_style=CLITheme.PRIMARY
        )
        self.console.print(welcome_panel)
    
    def print_team_status(self):
        """Imprime status da equipe"""
        status = self.team.get_team_status()
        
        # Tabela de agentes
        table = Table(title="[bold cyan]Status da Equipe[/bold cyan]", border_style=CLITheme.PRIMARY)
        table.add_column("Agente", style=CLITheme.PRIMARY)
        table.add_column("Papel", style=CLITheme.SECONDARY)
        table.add_column("Tarefas Completas", style=CLITheme.SUCCESS)
        table.add_column("Memória", style=CLITheme.INFO)
        
        for agent_name, agent_info in status["agents"].items():
            table.add_row(
                agent_name,
                agent_info["role"],
                str(agent_info["completed_tasks"]),
                f"{agent_info['memory_size']} msgs"
            )
        
        self.console.print(table)
        
        # Estatísticas gerais
        stats_text = f"""
[bold cyan]Estatísticas Gerais:[/bold cyan]
  Total de Tarefas: {status['total_tasks']}
  Tarefas Completas: {status['completed_tasks']}
  Taxa de Sucesso: {(status['completed_tasks'] / max(status['total_tasks'], 1) * 100):.1f}%
        """
        self.console.print(stats_text)
    
    def print_task_history(self):
        """Imprime histórico de tarefas"""
        if not self.team.task_history:
            self.console.print("[yellow]Nenhuma tarefa executada ainda[/yellow]")
            return
        
        table = Table(title="[bold cyan]Histórico de Tarefas[/bold cyan]", border_style=CLITheme.PRIMARY)
        table.add_column("ID", style=CLITheme.PRIMARY)
        table.add_column("Descrição", style=CLITheme.SECONDARY)
        table.add_column("Status", style=CLITheme.INFO)
        table.add_column("Resultado", style=CLITheme.SUCCESS)
        
        for task in self.team.task_history[-10:]:  # Últimas 10 tarefas
            status_color = {
                TaskStatus.COMPLETED: CLITheme.SUCCESS,
                TaskStatus.FAILED: CLITheme.ERROR,
                TaskStatus.RUNNING: CLITheme.WARNING,
                TaskStatus.PENDING: CLITheme.INFO
            }.get(task.status, CLITheme.INFO)
            
            table.add_row(
                task.id,
                task.description[:40] + "..." if len(task.description) > 40 else task.description,
                f"[{status_color}]{task.status.value}[/{status_color}]",
                task.result[:30] + "..." if task.result and len(task.result) > 30 else (task.result or "")
            )
        
        self.console.print(table)
    
    def print_agents_list(self):
        """Lista agentes disponíveis"""
        table = Table(title="[bold cyan]Agentes Disponíveis[/bold cyan]", border_style=CLITheme.PRIMARY)
        table.add_column("Nome", style=CLITheme.PRIMARY)
        table.add_column("Papel", style=CLITheme.SECONDARY)
        table.add_column("Modelo", style=CLITheme.INFO)
        
        for name, agent in self.team.agents.items():
            table.add_row(
                name,
                agent.config.role.value,
                agent.config.model
            )
        
        self.console.print(table)
    
    async def execute_task(self):
        """Executa uma nova tarefa"""
        self.console.print("\n[bold cyan]Criar Nova Tarefa[/bold cyan]")
        
        task_id = f"task_{len(self.team.task_history) + 1:03d}"
        description = Prompt.ask("[cyan]Descrição da tarefa")
        priority = int(Prompt.ask("[cyan]Prioridade (0-10)", default="5"))
        
        task = Task(
            id=task_id,
            description=description,
            priority=priority
        )
        
        # Executar com progresso
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TextColumn("[progress.percentage]{task.percentage:.0f}%"),
            console=self.console
        ) as progress:
            progress_task = progress.add_task("[cyan]Executando tarefa...", total=100)
            
            result = await self.team.execute_task(task)
            
            # Simular progresso
            for i in range(0, 100, 10):
                progress.update(progress_task, completed=i)
                await asyncio.sleep(0.1)
            progress.update(progress_task, completed=100)
        
        # Mostrar resultado
        result_panel = Panel(
            json.dumps(result, indent=2, ensure_ascii=False),
            title="[bold green]Resultado da Tarefa[/bold green]",
            border_style=CLITheme.SUCCESS
        )
        self.console.print(result_panel)
    
    def print_help(self):
        """Imprime ajuda"""
        help_text = """
[bold cyan]Comandos Disponíveis:[/bold cyan]

[bold]task[/bold]     - Criar e executar nova tarefa
[bold]status[/bold]   - Ver status da equipe
[bold]history[/bold]  - Ver histórico de tarefas
[bold]agents[/bold]   - Listar agentes disponíveis
[bold]config[/bold]   - Configurar plataforma
[bold]help[/bold]     - Mostrar esta ajuda
[bold]clear[/bold]    - Limpar tela
[bold]exit[/bold]     - Sair da aplicação

[bold cyan]Exemplos:[/bold cyan]

  task
    Criar uma nova tarefa interativamente

  status
    Ver status atual de todos os agentes

  history
    Ver últimas tarefas executadas
        """
        self.console.print(help_text)
    
    async def run(self):
        """Loop principal da CLI"""
        self.print_header()
        self.print_welcome()
        
        while True:
            try:
                command = Prompt.ask("\n[bold cyan]autogen[/bold cyan]").strip().lower()
                
                if command == "exit":
                    self.console.print("[bold yellow]Saindo...[/bold yellow]")
                    break
                elif command == "task":
                    await self.execute_task()
                elif command == "status":
                    self.print_team_status()
                elif command == "history":
                    self.print_task_history()
                elif command == "agents":
                    self.print_agents_list()
                elif command == "help":
                    self.print_help()
                elif command == "clear":
                    self.console.clear()
                    self.print_header()
                elif command == "config":
                    self.console.print("[yellow]Configuração em desenvolvimento[/yellow]")
                else:
                    self.console.print(f"[red]Comando desconhecido: {command}[/red]")
                    self.console.print("[yellow]Digite 'help' para ver comandos disponíveis[/yellow]")
            
            except KeyboardInterrupt:
                self.console.print("\n[bold yellow]Interrompido pelo usuário[/bold yellow]")
                break
            except Exception as e:
                self.console.print(f"[red]Erro: {str(e)}[/red]")


async def main():
    """Função principal"""
    cli = AutoGenCLI()
    await cli.run()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n\nAplicação encerrada.")
