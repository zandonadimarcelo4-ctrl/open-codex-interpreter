"""
AutoGen Elite Platform - Exemplos de Uso

Demonstra como usar a plataforma programaticamente
"""

import asyncio
from architecture import (
    AgentTeam,
    Task,
    TaskStatus,
    AgentConfig,
    AgentRole,
    InterpreterAgent,
    OrchestratorAgent
)
import json


async def example_1_basic_task():
    """Exemplo 1: Executar uma tarefa básica"""
    print("\n" + "="*60)
    print("EXEMPLO 1: Tarefa Básica")
    print("="*60)
    
    # Criar equipe
    team = AgentTeam()
    
    # Criar orquestrador
    orchestrator = OrchestratorAgent(
        AgentConfig(
            name="Orchestrator",
            role=AgentRole.ARCHITECT
        ),
        team={}
    )
    team.set_orchestrator(orchestrator)
    
    # Criar tarefa
    task = Task(
        id="task_001",
        description="Criar uma interface web moderna para chat com IA",
        priority=8
    )
    
    # Executar
    result = await team.execute_task(task)
    print("\nResultado:")
    print(json.dumps(result, indent=2, ensure_ascii=False))


async def example_2_multiple_agents():
    """Exemplo 2: Trabalhar com múltiplos agentes"""
    print("\n" + "="*60)
    print("EXEMPLO 2: Múltiplos Agentes")
    print("="*60)
    
    # Criar agentes
    architect = InterpreterAgent(AgentConfig(
        name="Architect",
        role=AgentRole.ARCHITECT,
        system_prompt="Você é um arquiteto de sistemas"
    ))
    
    developer = InterpreterAgent(AgentConfig(
        name="Developer",
        role=AgentRole.DEVELOPER,
        system_prompt="Você é um desenvolvedor"
    ))
    
    designer = InterpreterAgent(AgentConfig(
        name="Designer",
        role=AgentRole.DESIGNER,
        system_prompt="Você é um designer"
    ))
    
    # Criar equipe
    team = AgentTeam()
    team.add_agent(architect)
    team.add_agent(developer)
    team.add_agent(designer)
    
    # Criar orquestrador
    orchestrator = OrchestratorAgent(
        AgentConfig(
            name="Orchestrator",
            role=AgentRole.ARCHITECT
        ),
        team={
            "architect": architect,
            "developer": developer,
            "designer": designer
        }
    )
    team.set_orchestrator(orchestrator)
    
    # Executar tarefa
    task = Task(
        id="task_002",
        description="Implementar nova feature de chat em tempo real",
        priority=9
    )
    
    result = await team.execute_task(task)
    print("\nResultado:")
    print(json.dumps(result, indent=2, ensure_ascii=False))
    
    # Ver status
    print("\nStatus da Equipe:")
    status = team.get_team_status()
    print(json.dumps(status, indent=2, ensure_ascii=False))


async def example_3_task_with_dependencies():
    """Exemplo 3: Tarefas com dependências"""
    print("\n" + "="*60)
    print("EXEMPLO 3: Tarefas com Dependências")
    print("="*60)
    
    team = AgentTeam()
    orchestrator = OrchestratorAgent(
        AgentConfig(
            name="Orchestrator",
            role=AgentRole.ARCHITECT
        ),
        team={}
    )
    team.set_orchestrator(orchestrator)
    
    # Criar tarefas com dependências
    task1 = Task(
        id="task_001",
        description="Planejar arquitetura",
        priority=10
    )
    
    task2 = Task(
        id="task_002",
        description="Implementar backend",
        priority=9,
        dependencies=["task_001"]
    )
    
    task3 = Task(
        id="task_003",
        description="Implementar frontend",
        priority=9,
        dependencies=["task_001"]
    )
    
    # Executar
    results = []
    for task in [task1, task2, task3]:
        result = await team.execute_task(task)
        results.append(result)
    
    print("\nResultados:")
    for result in results:
        print(f"- {result['task_id']}: {result['status']}")


async def example_4_agent_memory():
    """Exemplo 4: Usar memória do agente"""
    print("\n" + "="*60)
    print("EXEMPLO 4: Memória do Agente")
    print("="*60)
    
    # Criar agente
    agent = InterpreterAgent(AgentConfig(
        name="Developer",
        role=AgentRole.DEVELOPER,
        memory_size=5
    ))
    
    # Adicionar mensagens à memória
    agent.add_to_memory("user", "Qual é a melhor forma de estruturar um projeto React?")
    agent.add_to_memory("assistant", "Use componentes reutilizáveis e state management...")
    agent.add_to_memory("user", "E para backend?")
    agent.add_to_memory("assistant", "Use APIs RESTful com separação de camadas...")
    
    # Ver contexto
    print("\nContexto da Memória:")
    print(agent.get_memory_context())
    
    print(f"\nTamanho da memória: {len(agent.memory)} mensagens")


async def example_5_custom_agent():
    """Exemplo 5: Criar agente customizado"""
    print("\n" + "="*60)
    print("EXEMPLO 5: Agente Customizado")
    print("="*60)
    
    from architecture import Agent, Task
    
    class DataAnalystAgent(Agent):
        """Agente especializado em análise de dados"""
        
        async def execute(self, task: Task) -> str:
            self.add_to_memory("user", task.description)
            
            # Simular análise
            result = f"Análise de dados: {task.description}\n"
            result += "- Estatísticas: OK\n"
            result += "- Visualizações: OK\n"
            result += "- Relatório: Gerado"
            
            self.add_to_memory("assistant", result)
            return result
        
        async def think(self, context: str) -> str:
            return f"Analisando dados: {context}"
    
    # Usar agente customizado
    config = AgentConfig(
        name="DataAnalyst",
        role=AgentRole.ANALYST,
        system_prompt="Você é um especialista em análise de dados"
    )
    
    agent = DataAnalystAgent(config)
    
    task = Task(
        id="task_001",
        description="Analisar dados de vendas do último trimestre"
    )
    
    result = await agent.execute(task)
    print("\nResultado:")
    print(result)


async def main():
    """Executar todos os exemplos"""
    print("\n" + "="*60)
    print("AutoGen Elite Platform - Exemplos de Uso")
    print("="*60)
    
    try:
        # Exemplo 1
        await example_1_basic_task()
        
        # Exemplo 2
        await example_2_multiple_agents()
        
        # Exemplo 3
        await example_3_task_with_dependencies()
        
        # Exemplo 4
        await example_4_agent_memory()
        
        # Exemplo 5
        await example_5_custom_agent()
        
        print("\n" + "="*60)
        print("✅ Todos os exemplos executados com sucesso!")
        print("="*60)
    
    except Exception as e:
        print(f"\n❌ Erro ao executar exemplos: {str(e)}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    asyncio.run(main())
