import argparse
import inquirer
from rich.console import Console
from rich.panel import Panel
from rich.text import Text

def cli(interpreter):
  """
  Takes an instance of interpreter.
  Modifies it according to command line flags, then runs chat.
  """
  console = Console()

  # Banner de Boas-Vindas Aprimorado
  welcome_text = Text("🚀 Super Agente Inovador (Open Interpreter + AutoGen + Ollama) 🚀", justify="center")
  welcome_panel = Panel(welcome_text, title="[bold green]Bem-Vindo[/bold green]", border_style="green")
  console.print(welcome_panel)

  console.print("[bold yellow]Dica:[/bold yellow] Use 'exit' ou 'quit' para sair. O agente agora tem memória de longo prazo e ferramentas web.")
  console.print("-" * 50)

  # Setup CLI
  parser = argparse.ArgumentParser(description='Chat with Open Interpreter.')
  
  parser.add_argument('-y',
                      '--yes',
                      action='store_true',
                      help='execute code without user confirmation')
  parser.add_argument('-f',
                      '--fast',
                      action='store_true',
                      help='use gpt-3.5-turbo instead of gpt-4')
  parser.add_argument('-l',
                      '--local',
                      action='store_true',
                      help='run fully local with code-llama')
  parser.add_argument('-d',
                      '--debug',
                      action='store_true',
                      help='prints extra information')
  args = parser.parse_args()

  # Modify interpreter according to command line flags
  if args.yes:
    interpreter.auto_run = True
  if args.fast:
    interpreter.model = "gpt-3.5-turbo"
  if args.local:
    interpreter.local = True
  if args.debug:
    interpreter.debug_mode = True

  # Run the chat method
  interpreter.chat()
