from chromadb import Client
from interpreter.interpreter import Interpreter # Import Interpreter to use its client

def initialize_knowledge_base():
    """
    Initializes a ChromaDB collection with some example knowledge for RAG.
    """
    # Use the same client as the Interpreter
    interpreter = Interpreter()
    db_client = interpreter.db_client

    # Create a collection for the knowledge base
    collection_name = "knowledge_base"
    try:
        collection = db_client.get_collection(collection_name)
    except:
        collection = db_client.create_collection(collection_name)

    # Example documents to populate the knowledge base
    documents = [
        "O agente deve sempre priorizar a segurança e pedir confirmação antes de executar comandos de sistema.",
        "A função principal do agente é executar código Python e Shell para resolver problemas do usuário.",
        "Para tarefas de automação web, o agente deve usar a biblioteca Playwright.",
        "O agente possui um módulo de auto-correção que é ativado após falhas de execução de código.",
        "O modelo de linguagem principal configurado é o GPT-4, mas pode ser trocado para Code-Llama com a flag --local."
    ]
    
    # Generate IDs for the documents
    ids = [f"doc_{i}" for i in range(len(documents))]

    # Add documents to the collection
    collection.add(
        documents=documents,
        ids=ids
    )
    
    print(f"Knowledge base '{collection_name}' initialized with {len(documents)} documents.")

if __name__ == "__main__":
    initialize_knowledge_base()
