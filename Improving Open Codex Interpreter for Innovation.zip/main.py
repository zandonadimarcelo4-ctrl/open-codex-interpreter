import os
import json
import subprocess
from autogen import AssistantAgent, UserProxyAgent, config_list_ollama
from autogen.agentchat.contrib.retrieve_assistant_agent import RetrieveAssistantAgent
from autogen.agentchat.contrib.retrieve_user_proxy_agent import RetrieveUserProxyAgent

# --- Configurações ---
# OLLAMA_BASE e MODEL serão lidos do ambiente ou definidos como padrão
OLLAMA_BASE = os.environ.get("OLLAMA_BASE", "http://127.0.0.1:11434")
MODEL = os.environ.get("MODEL", "deepseek-r1:8b")

# Configuração para o AutoGen usar o Ollama
config_list = [
    {
        "model": MODEL,
        "base_url": OLLAMA_BASE,
        "api_type": "ollama",
    }
]

# --- Funções de Ferramenta ---

def run_local_code(code: str) -> str:
    """
    Executa código localmente usando o Open Interpreter Core.
    A flag -y é usada para aprovar automaticamente a execução.
    """
    print(f"\n--- Executando Código Local ---\n{code}\n------------------------------")
    try:
        # Usamos o CLI do Open Interpreter.
        # O Open Interpreter Core (interpreter.py) já está configurado para usar o ChromaDB para RAG.
        process = subprocess.run(
            ["interpreter", "-y", "--local"],
            input=code.encode(),
            capture_output=True,
            text=True,
            check=True
        )
        return f"Código executado com sucesso. Saída:\n{process.stdout}\nErros (se houver):\n{process.stderr}"
    except subprocess.CalledProcessError as e:
        return f"Erro na execução do código:\n{e.stderr}"
    except FileNotFoundError:
        return "Erro: O comando 'interpreter' não foi encontrado. Certifique-se de que o Open Interpreter está instalado corretamente."

# --- Agentes ---

# 1. Agente Gerador (DeepSeek-R1 via Ollama)
# Responsável por gerar o raciocínio e o código.
generator = AssistantAgent(
    name="Generator",
    llm_config={"config_list": config_list},
    system_message="Você é um engenheiro de software experiente. Sua tarefa é criar um plano de desenvolvimento e gerar o código Python ou Shell necessário para resolver o problema. Use a função `run_local_code` para executar o código. Após a execução, analise a saída e, se necessário, corrija o código ou continue o desenvolvimento."
)

# 2. Agente Crítico (DeepSeek-R1 via Ollama)
# Responsável por revisar o código e a saída, garantindo a qualidade e a correção de erros.
critic = AssistantAgent(
    name="Critic",
    llm_config={"config_list": config_list},
    system_message="Você é um crítico de código rigoroso e um avaliador de resultados. Sua tarefa é revisar o código gerado e a saída da execução. Se a saída indicar um erro ou o resultado não atender ao objetivo, forneça feedback detalhado ao Generator para correção. Não gere código, apenas critique e sugira melhorias."
)

# 3. Agente Usuário Proxy (Interface)
# Atua como a interface do usuário e o executor de código.
user_proxy = UserProxyAgent(
    name="User_Proxy",
    human_input_mode="ALWAYS", # Pede confirmação para o usuário antes de executar
    max_consecutive_auto_reply=10,
    is_termination_msg=lambda x: "TERMINATE" in x.get("content", "").upper(),
    code_execution_config={"work_dir": "coding", "use_docker": False},
    function_map={"run_local_code": run_local_code}
)

# --- Orquestração ---

def run_unified_agent():
    """
    Inicia o loop de conversação do agente unificado.
    """
    print("\n" + "="*50)
    print("🚀 Unified Dev Agent (AutoGen + Ollama + Open Interpreter) 🚀")
    print("="*50 + "\n")
    print(f"Modelo LLM: {MODEL} em {OLLAMA_BASE}")
    print("Digite 'exit' ou 'TERMINATE' para sair.")

    # O loop principal de conversação
    user_input = input("\n💡 Qual é o seu objetivo de desenvolvimento?\n> ")

    if user_input.lower() in ["exit", "terminate"]:
        return

    # Inicia a conversa: User_Proxy -> Generator -> Critic
    user_proxy.initiate_chat(
        generator,
        message=user_input,
        recipient=critic # O Generator envia a primeira mensagem para o Critic para revisão
    )

if __name__ == "__main__":
    # Garante que o diretório de trabalho exista
    os.makedirs("coding", exist_ok=True)
    
    # Instala o Playwright para o WebTool
    subprocess.run(["playwright", "install"], check=False)

    # O Open Interpreter Core precisa ser executado em um ambiente onde as ferramentas estejam disponíveis.
    # Como estamos usando o CLI, ele deve herdar o ambiente virtual.
    
    # Opcional: Adicionar um loop para manter o agente ativo
    run_unified_agent()
