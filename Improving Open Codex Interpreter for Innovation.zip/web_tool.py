import json
import asyncio
from playwright.async_api import async_playwright

class WebTool:
    """
    Ferramenta de navegação web autônoma usando Playwright.
    Permite ao agente interagir com páginas web, extrair conteúdo e tirar screenshots.
    """
    def __init__(self, debug_mode=False):
        self.debug_mode = debug_mode
        self.browser = None
        self.page = None

    async def _initialize_browser(self):
        if self.browser is None:
            self.playwright = await async_playwright().start()
            self.browser = await self.playwright.chromium.launch(headless=True)
            self.page = await self.browser.new_page()
            if self.debug_mode:
                print("WebTool: Browser initialized.")

    async def _close_browser(self):
        if self.browser:
            await self.browser.close()
            await self.playwright.stop()
            self.browser = None
            self.page = None
            if self.debug_mode:
                print("WebTool: Browser closed.")

    async def navigate(self, url: str) -> str:
        """Navega para a URL especificada e retorna o conteúdo da página."""
        await self._initialize_browser()
        try:
            await self.page.goto(url)
            content = await self.page.content()
            return f"Successfully navigated to {url}. Page title: {await self.page.title()}. Content snippet: {content[:500]}..."
        except Exception as e:
            return f"Error navigating to {url}: {e}"

    async def click(self, selector: str) -> str:
        """Clica no elemento especificado pelo seletor CSS."""
        if not self.page:
            return "Error: Browser not initialized. Call navigate() first."
        try:
            await self.page.click(selector)
            return f"Successfully clicked on element with selector: {selector}. Current page title: {await self.page.title()}"
        except Exception as e:
            return f"Error clicking on element with selector {selector}: {e}"

    async def fill(self, selector: str, text: str) -> str:
        """Preenche o campo de entrada especificado pelo seletor CSS com o texto."""
        if not self.page:
            return "Error: Browser not initialized. Call navigate() first."
        try:
            await self.page.fill(selector, text)
            return f"Successfully filled element with selector: {selector} with text: '{text}'"
        except Exception as e:
            return f"Error filling element with selector {selector}: {e}"

    async def screenshot(self, path: str) -> str:
        """Tira um screenshot da página e salva no caminho especificado."""
        if not self.page:
            return "Error: Browser not initialized. Call navigate() first."
        try:
            await self.page.screenshot(path=path)
            return f"Successfully saved screenshot to: {path}"
        except Exception as e:
            return f"Error taking screenshot: {e}"

    def run_sync(self, method_name: str, *args, **kwargs):
        """Executa um método assíncrono de forma síncrona."""
        method = getattr(self, method_name)
        return asyncio.run(method(*args, **kwargs))

# Exemplo de uso (para teste)
if __name__ == "__main__":
    tool = WebTool(debug_mode=True)
    
    async def test_web_tool():
        print(await tool.navigate("https://www.google.com"))
        print(await tool.fill('textarea[name="q"]', "super agente inovador"))
        print(await tool.click('input[name="btnK"]'))
        print(await tool.screenshot("google_search.png"))
        await tool._close_browser()

    asyncio.run(test_web_tool())
